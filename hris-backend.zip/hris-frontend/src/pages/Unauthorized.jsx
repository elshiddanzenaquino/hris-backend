const Unauthorized = () => {
  return (
    <div className="flex h-screen justify-center items-center">
      <h1 className="text-4xl font-bold text-red-600">Unauthorized Access</h1>
    </div>
  );
};

export default Unauthorized;
